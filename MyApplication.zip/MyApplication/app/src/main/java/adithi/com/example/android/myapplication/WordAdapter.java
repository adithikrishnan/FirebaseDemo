package adithi.com.example.android.myapplication;

public class WordAdapter {
}
